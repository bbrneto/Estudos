package br.com.casadocodigo.loja.configuration;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringSecurityFilterConfiguration 
	extends AbstractSecurityWebApplicationInitializer {

}
