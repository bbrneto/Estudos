# Projeto Alura Shows!

Index

![index](https://media.giphy.com/media/xT9IgwKKAKMcrhV5Be/giphy.gif)

Admin

![admin](https://media.giphy.com/media/xT9IgKhcbcvAcx4Eec/giphy.gif)

Login

![login](https://media.giphy.com/media/xT9IgO0n4cb311s06Y/giphy.gif)

Blog

![blog](https://media.giphy.com/media/3o7aD52RkT29CAdd1S/giphy.gif)

Registrar

![registrar](https://media.giphy.com/media/3ov9jNDmww9BGZR25q/giphy.gif)
